clc
clear all
%%
m = 11;
bits = randi([0 1], m,1)
x = encode(bits, 4)

%%
m=11;
bits = randi([0 1], m,1)
r=4;
%%
p=encoding(bits,r)
%%
x=[bits;p];
sum(x)
