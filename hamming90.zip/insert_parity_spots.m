
function E=insert_parity_spots(bits,r)
clearvars D E
nb_bits_parity=r;
D=bits;
E=zeros(1,length(D)+nb_bits_parity);
%puts zeros in the matrix at every 2^n position
 
E;
%Inserts message string at the right places (everywhere but pos=2^n) in the
%message vector
D=D';
for M=1:length(E)
    count=floor(log2(M)+1);
    if M-count>0
        
        
        E(1,M)=D(1,M-count);
       
    end
end
E;