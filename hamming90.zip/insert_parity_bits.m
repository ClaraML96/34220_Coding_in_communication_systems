function E=insert_parity_bits(bits,r)
r=r;
A=bits;
%E=encode(A,r);
E=insert_parity_spots(A,r);
%E=E';
P=generate_hamming_matrix(E,r);

%%%%%%%%%%%%%%%%%
%Finds spots in the message string where bits are = 1
for V=1:r
    Q(V,:)=P(V,:).*E; 
end
Q;
%For each parity line, finds if the sum of bits that are 1 is even (0), or odd (1)
for U=1:r
    %R(U,:)=mod(length(find(Q(U,:))),2);
    R(U,:)=mod(sum(Q(U,:)),2);
end
%%%%%%%%%%%%%%%%%
R;
%Adds the necessary parity bits in the message
for S=0:r-1
    E(1,2^S)=R(S+1,1);
end
E;