function p=encoding(bits,r)
E=insert_parity_spots(bits,r);
P=generate_hamming_matrix(E,r);
[n,m]=size(P);
p=zeros(n,1);

for i=1:n
    y=find(P(i,:));
    pp=0;
    for j=2:length(y)
        x=y(j);
        pp=pp+E(x);
    end
    p(i)=mod(pp,2);
    %p(i)=mod(sum(P(i,:)-1),2);
end
% I=eye(length(bits));
% G=[I;P];
% X=mod(sum(E.*pp'),2)

% p1 = d1+d2+d4
% p2 = d1+d3+d4
% p3 = d2+d3+d4

end