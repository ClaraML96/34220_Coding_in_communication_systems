function x = encode(bits, r)
n = length(bits) + r;
x = zeros(n,1);
j = 1;
for i = 2:n+1
    if mod(log2(i-1),1) == 0
        continue
    end
    x(i) = bits(j);
    j = j + 1;
end
% for i = 2:n+1
%     if mod(log2(i-1),1) == 1
%         
%     
% end
% for i = 1
%     %add all 1's and make even/odd    
% end
        
end